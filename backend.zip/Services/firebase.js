// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCiLDDaDKFNnEf1gclo1IiUUX4zrKCNq18",
  authDomain: "wfw-expert-system-cff9e.firebaseapp.com",
  projectId: "wfw-expert-system-cff9e",
  storageBucket: "wfw-expert-system-cff9e.appspot.com",
  messagingSenderId: "262156476109",
  appId: "1:262156476109:web:365400f1336a76e3bb1384"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);